package com.example.mangareader;

public class chapterModel {

    private String chapter_name;

    public chapterModel(String chapter_name) {
        this.chapter_name = chapter_name;
    }

    public String getChapter_name() {
        return chapter_name;
    }

    public void setChapter_name(String chapter_name) {
        this.chapter_name = chapter_name;
    }
}
