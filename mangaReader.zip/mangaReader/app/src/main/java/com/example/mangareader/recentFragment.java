package com.example.mangareader;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toolbar;

import java.util.ArrayList;

public class recentFragment extends Fragment {

    RecyclerView recyclerView;
    ArrayList<comicModel> comicList;
    Toolbar recentToolbar;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_recent, container, false);

        recyclerView = view.findViewById(R.id.rv);
        recentToolbar = view.findViewById(R.id.recentToolbar);
        recentToolbar.setTitle("Recent");

        comicList = new ArrayList<>();
        comicList.add(new comicModel(R.drawable.one_piece, "One Piece", "Action"));
        comicList.add(new comicModel(R.drawable.one_piece, "One Piece", "Action"));
        comicList.add(new comicModel(R.drawable.one_piece, "One Piece", "Action"));
        comicList.add(new comicModel(R.drawable.one_piece, "One Piece", "Action"));
        comicList.add(new comicModel(R.drawable.one_piece, "One Piece", "Action"));
        comicList.add(new comicModel(R.drawable.one_piece, "One Piece", "Action"));
        comicList.add(new comicModel(R.drawable.one_piece, "One Piece", "Action"));
        comicList.add(new comicModel(R.drawable.one_piece, "One Piece", "Action"));
        comicList.add(new comicModel(R.drawable.one_piece, "One Piece", "Action"));


        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        RecyclerView.LayoutManager rvLiLayoutManager = layoutManager;

        recyclerView.setLayoutManager(rvLiLayoutManager);

        comicAdapter adapter = new comicAdapter(getContext(),comicList);
        recyclerView.setAdapter(adapter);

        return view;
    }
}
