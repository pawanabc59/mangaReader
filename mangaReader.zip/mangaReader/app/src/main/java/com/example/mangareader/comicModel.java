package com.example.mangareader;

public class comicModel {

    private int image;
    private String name, category;

    public comicModel(int image, String name, String category) {
        this.image = image;
        this.name = name;
        this.category = category;
    }

    public int getImage() {
        return image;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCategory(String category) {
        this.category = category;
    }

}
