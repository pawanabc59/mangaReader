package com.example.mangareader;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

public class favouriteFragment extends Fragment {

    Context thisContext;
    List<comic> lstComic;
    RecyclerView myrecyclerview;
    Toolbar fav_Toolbar;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

//        thisContext = container.getContext();

        View view = inflater.inflate(R.layout.fragment_favourite, container, false);

        fav_Toolbar = view.findViewById(R.id.fav_Toolbar);
        fav_Toolbar.setTitle("Favourites");

        lstComic = new ArrayList<>();
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));
//        lstComic.add(new comic("One Piece", "Category Comic", "Description Comic", R.drawable.one_piece));

        myrecyclerview = view.findViewById(R.id.recyclerId);
        RecyclerViewAdapter myAdapter = new RecyclerViewAdapter(getContext(), lstComic);
        GridLayoutManager manager = new GridLayoutManager(getContext(), 3, GridLayoutManager.VERTICAL, false);
//        LinearLayoutManager manager = new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false);
        myrecyclerview.setLayoutManager(manager);
        myrecyclerview.setAdapter(myAdapter);

        return view;
    }
}
